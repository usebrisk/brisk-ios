//
//  Brisk_framework.h
//  Brisk framework
//
//  Created by Nermin Sehic on 15. 12. 2021..
//

#import <Foundation/Foundation.h>

//! Project version number for Brisk_framework.
FOUNDATION_EXPORT double Brisk_frameworkVersionNumber;

//! Project version string for Brisk_framework.
FOUNDATION_EXPORT const unsigned char Brisk_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Brisk_framework/PublicHeader.h>


